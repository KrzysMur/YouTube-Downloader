from pytube import YouTube
import sys
import os
from pathlib import Path


def main():
    arguments = sys.argv[1:]

    URL = YouTube(arguments[0])
    stream = URL.streams.filter(only_audio=True)[-1]

    with open("destination.txt") as file:
        destination = file.read()[2:]

    print(f"Downloading {URL.title} to {destination} ...")

    os.chdir(os.path.join(Path.home(), destination))

    stream.download()

    print("Downloading completed")


if __name__ == "__main__":
    main()
